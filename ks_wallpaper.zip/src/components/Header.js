import { Link } from "react-router-dom";
import React, { useState, useEffect } from 'react';

const Header = ({ Nav }) => {

    const [header, setHeader] = useState(0);
    const updateScroll = () => {
        setHeader(window.scrollY || document.documentElement.scrollTop);
    }
    useEffect(() => {
        window.addEventListener('scroll', updateScroll);
    });

    return (
        <>
            <header className={header < 100 ? "header" : "header_fix"}>
                <div className="inner">
                    <h1>
                        <Link to='/'>
                            <img src={process.env.PUBLIC_URL + `/img/logo.png`} alt="" />
                        </Link>
                    </h1>
                    <nav className="gnb">
                        <ul>
                            {
                                Nav.map((it, idx) => (
                                    <li key={idx}>
                                        <Link to={it.Lik}>{it.NavTitle}</Link>

                                        <ul className="drop_menu">
                                            {
                                                it.Submenu.map((sub, idx) => (
                                                    <li key={idx}>
                                                        <Link to={sub.Lik}>{sub.Title}</Link>
                                                    </li>
                                                ))
                                            }
                                        </ul>

                                    </li>
                                ))
                            }
                        </ul>
                    </nav>
                </div>
            </header>
        </>
    )
}

export default Header;