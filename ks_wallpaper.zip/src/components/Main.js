import Slider from "react-slick";
import "slick-carousel/slick/slick.css";
import { BsChevronRight, BsChevronLeft } from "react-icons/bs";
import { Link } from "react-router-dom";
import { useEffect, useState } from "react";
const MainSlide = {
    dots: true,
    infinite: true,
    speed: 500,
    slidesToShow: 1,
    slidesToScroll: 1,
    nextArrow: <BsChevronRight />,
    prevArrow: <BsChevronLeft />
};

const Main = ({ MainVisual, Collection }) => {

    const [sNum, setSNum] = useState();

    useEffect(() => {
        setSNum(0);
    }, [])


    return (
        <>
            <section className="MainVisual">
                <div className="mainSlide">
                    <Slider {...MainSlide}>
                        {
                            MainVisual.map((it, idx) => {
                                return (
                                    <figure className={`M_slide_itm0${idx + 1}`} key={idx}>
                                        <div className="inner">
                                            <h2>{it.Title}</h2>
                                            <p>{it.Desc}</p>
                                            <span>{it.SubText}</span>
                                        </div>
                                    </figure>
                                )
                            })
                        }
                    </Slider>
                    <div className="num">
                        <strong>{sNum + 1}</strong> / <span>{MainVisual.length}</span>
                    </div>
                </div>
            </section>

            <section className="MainColletion"></section>
            <section className="MainSns"></section>
        </>
    )
}

export default Main;